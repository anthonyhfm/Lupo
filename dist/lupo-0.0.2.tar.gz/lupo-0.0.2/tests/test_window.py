import lupo

win = lupo.Window()

win.open_window()